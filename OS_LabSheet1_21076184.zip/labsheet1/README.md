##LabSheet1


# Create a remote repository

# Clone the repository locally

- git clone https://gitlab.uwe.ac.uk/as25-ahmed/labsheet1.git

# Move to the cloned folder 

- cd labsheet1

# List the files inside the folder using "ls"

# Edit the README.md file 

- vim README.md
- after editing use w command to save the file and q to exit edit mode

# Check Status using "git status"

# use git add - "git add ."

# Commit the changes done to the file

- git commit - m "comment"

# Push the changes to remote repository

- git push origin master

# Fork an existing repository

- open a friend remote repository 
- press fork

# clone the forked repository locally

- git clone https://gitlab.uwe.ac.uk/as25-ahmed/testproject.git 

